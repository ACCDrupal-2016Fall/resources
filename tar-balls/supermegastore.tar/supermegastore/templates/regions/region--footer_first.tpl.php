<?php
/**
 * @file
 * Returns the HTML for the footer_first region.
 *
 * Complete documentation for this file is available online.
 * @see https://drupal.org/node/1728140
 */
?>

<?php if ($content): ?>
  <div class="footer-first"> <!-- footer-first -->
    <?php print $content; ?>
  </div>
  <!-- /.footer-first -->
<?php endif; ?>
